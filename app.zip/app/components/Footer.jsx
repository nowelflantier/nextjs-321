// "use client";
// import Image from "next/image";
// import Link from "next/link";
// // import styles from "../../styles.scss";
// import React, { useState, useEffect } from "react";

// const Footer = () => {
// return (
// <div className="center container">
// <p className="code">
//   work in progress
//   <br />
// </p>
// <Link href="/" className="bottom btn">
//   <p>Back home</p>
// </Link>
// <Link href="/321/select-players?new_game=true" className="bottom btn">
//   <p>Nouvelle partie</p>
// </Link>
// </div>)
// }

// export default Footer;